Keep your existing materials folder here, including quiz DOCX files referenced by index.html.
