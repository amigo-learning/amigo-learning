Keep your existing assets folder here. This upgrade intentionally preserves references such as assets/logo.png, assets/banner.png, assets/founder.jpg and assets/students.jpg.
