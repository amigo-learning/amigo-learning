# Amigo Academy

Upgraded frontend of the existing Amigo project.

## Important
This version preserves the existing single-page architecture, resource links, quiz system, course data, university directory and assets while rebranding and expanding the platform as **Amigo Academy**.

### New learning architecture
- Preschool / ECD
- Primary 1–8
- Secondary 1–4
- University
- Professional & Career Skills
- Digital Academy
- Primary 8 / Senior 4 / University past-paper centre
- Free quiz centre
- Video learning centre
- AI Tutor prototype
- Learner dashboard prototype

## GitHub
Replace the existing `index.html` with the upgraded `index.html` from this package.

Do not delete your existing:
- `assets/`
- `materials/`
- `Course-Materials.zip`

The HTML continues to reference those resources.

## Test
Open with VS Code Live Server or serve the repository as a static GitHub Pages site.
