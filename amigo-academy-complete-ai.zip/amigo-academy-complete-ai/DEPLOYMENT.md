# Deployment

Architecture:

Browser -> GitHub Pages frontend -> secure Node backend -> Hugging Face Router API

Do not commit `.env` or any real `hf_...` token.

For cross-domain deployment, add CORS to the backend and change `/api/tutor` in `index.html` to your backend URL.
