# Amigo Academy — AI Tutor

This package upgrades the existing Amigo Academy frontend and adds a secure server-side AI Tutor.

## Security
Never put a Hugging Face token in HTML or browser JavaScript. The browser calls `/api/tutor`; the Node server reads `HF_TOKEN` from the environment.

The token previously pasted into chat is exposed. Revoke/rotate it and create a new token before deployment.

## Local test
1. Install Node.js.
2. Open this folder in VS Code terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your NEW token in `.env`.
6. Run `npm start`.
7. Open `http://localhost:3000`.
8. Test `http://localhost:3000/health`.

## GitHub Pages
GitHub Pages can host the frontend but cannot run this Node/Express API. Deploy the backend to a Node-capable host and store `HF_TOKEN` as a server secret. Then change the frontend fetch URL from `/api/tutor` to your backend URL if the domains differ.

Keep the existing Amigo `assets/`, `materials/`, PDFs, quiz DOCX files and other resources in your repository.
